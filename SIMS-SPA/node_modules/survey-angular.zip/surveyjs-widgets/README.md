Custom Widgets for the SurveyJS library

##Getting started
[![Join the chat at https://gitter.im/andrewtelnov/surveyjs](https://badges.gitter.im/andrewtelnov/surveyjs.svg)](https://gitter.im/andrewtelnov/surveyjs?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

To find our examples go to the [surveyjs.io site](e.g. https://surveyjs.io/Examples/Library/?id=custom-widget-select2)

##License

MIT license - [http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)

##SurveyJS library

SurveyJS library sources are [here](https://github.com/surveyjs/surveyjs)

##Visual Editor

Visual Editor sources are [here](https://github.com/surveyjs/editor)