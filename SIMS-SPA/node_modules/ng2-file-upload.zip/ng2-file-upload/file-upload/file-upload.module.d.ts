export declare class FileUploadModule {
}
